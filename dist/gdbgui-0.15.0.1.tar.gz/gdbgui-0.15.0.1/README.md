<p align="center">
<a href="http://gdbgui.com"><img src="https://github.com/cs01/gdbgui/raw/master/images/gdbgui_banner.png"></a>
</p>

<h3 align="center">
A browser-based frontend to gdb (gnu debugger)
</h3>

<p align="center">

<a href="https://github.com/cs01/gdbgui/actions">
<img src="https://github.com/cs01/gdbgui/workflows/Tests/badge.svg?branch=master" alt="image" /></a>

<a href="https://badge.fury.io/py/gdbgui">
<img src="https://badge.fury.io/py/gdbgui.svg" alt="PyPI version" >
</a>

<img src="https://pepy.tech/badge/gdbgui" alt="image" />

</p>

---

**Documentation**: https://gdbgui.com

**Source Code**: https://github.com/cs01/gdbgui/
